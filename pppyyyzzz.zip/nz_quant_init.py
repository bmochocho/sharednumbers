"""
NZ Quant パッケージ

時系列データ分析のための計量分析ツールパッケージ。
主要コンポーネントとして、オンライン学習による予測器と
バックテスト機能を提供します。
"""

from .predict_unit.online_pooling_dtw_knn import OnlinePoolingDTWKNN
from .predict_unit.backtest import run_backtest, run_file_based_backtest

__version__ = '1.0.0'