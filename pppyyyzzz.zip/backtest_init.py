"""
バックテストモジュール

予測器モデルのバックテスト実行と評価を行うための機能を提供します。
"""

from .backtest_base import (
    BacktestOptions,
    BacktestResult,
    calculate_metrics,
    visualize_results
)

from .online import (
    run_backtest,
    run_file_based_backtest,
    run_db_based_backtest,
    compare_k_values
)