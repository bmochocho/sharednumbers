"""
基本的な距離関数を提供するモジュール

スカラー値および多次元データに対する様々な距離計算関数を実装しています。
"""

import logging
from pythonjsonlogger import jsonlogger
from typing import TypeAlias, Callable, Union, List, Dict, Any
import numpy as np

# ロギング設定
logger = logging.getLogger(__name__)
logHandler = logging.StreamHandler()
formatter = jsonlogger.JsonFormatter('%(asctime)s %(name)s %(levelname)s %(message)s')
logHandler.setFormatter(formatter)
logger.addHandler(logHandler)

# 型エイリアス
DistanceFunction: TypeAlias = Callable[[Union[float, int], Union[float, int]], float]
Vector = List[Union[float, int]]

def euclidean_distance(x: Union[float, int], y: Union[float, int]) -> float:
    """
    ユークリッド距離（二乗誤差）を計算します。
    
    Parameters
    ----------
    x : Union[float, int]
        最初の値
    y : Union[float, int]
        2番目の値
        
    Returns
    -------
    float
        ユークリッド距離（二乗誤差）
    """
    return (x - y) ** 2

def manhattan_distance(x: Union[float, int], y: Union[float, int]) -> float:
    """
    マンハッタン距離（絶対誤差）を計算します。
    
    Parameters
    ----------
    x : Union[float, int]
        最初の値
    y : Union[float, int]
        2番目の値
        
    Returns
    -------
    float
        マンハッタン距離（絶対誤差）
    """
    return abs(x - y)

def maximum_distance(x: Union[float, int], y: Union[float, int]) -> float:
    """
    最大値距離を計算します。
    
    Parameters
    ----------
    x : Union[float, int]
        最初の値
    y : Union[float, int]
        2番目の値
        
    Returns
    -------
    float
        最大値距離
    """
    return float(max(abs(x - y), 0))

def get_distance_function(distance_name: str = 'Manhattan') -> DistanceFunction:
    """
    指定された名前の距離関数を返します。
    
    Parameters
    ----------
    distance_name : str, default='Manhattan'
        距離関数の名前
        
    Returns
    -------
    DistanceFunction
        対応する距離計算関数
        
    Notes
    -----
    サポートされている距離関数:
    - 'Manhattan': 絶対値距離 |x - y|
    - 'Euclidean': 二乗距離 (x - y)^2
    - 'Maximum': 最大値距離 max(|x - y|, 0)
    """
    distance_functions = {
        'Manhattan': manhattan_distance,
        'Euclidean': euclidean_distance,
        'Maximum': maximum_distance
    }
    
    if distance_name in distance_functions:
        return distance_functions[distance_name]
    else:
        logger.warning(f"未知の距離関数名: {distance_name}、マンハッタン距離を使用します")
        return manhattan_distance

def calculate_scalar_distance(x: Union[float, int], 
                             y: Union[float, int], 
                             distance_name: str = 'Manhattan') -> float:
    """
    2つのスカラー値間の距離を計算します。
    
    Parameters
    ----------
    x : Union[float, int]
        最初の値
    y : Union[float, int]
        2番目の値
    distance_name : str, default='Manhattan'
        使用する距離関数の名前
        
    Returns
    -------
    float
        計算された距離
    """
    distance_func = get_distance_function(distance_name)
    return distance_func(x, y)

def vector_distance(v1: Vector, v2: Vector, distance_name: str = 'Manhattan') -> float:
    """
    2つのベクトル間の距離を計算します。
    
    Parameters
    ----------
    v1 : Vector
        最初のベクトル
    v2 : Vector
        2番目のベクトル
    distance_name : str, default='Manhattan'
        使用する距離関数の名前
        
    Returns
    -------
    float
        計算された距離
        
    Notes
    -----
    ベクトルの長さが異なる場合、最小の長さに合わせます。
    """
    if len(v1) == 0 or len(v2) == 0:
        logger.warning("空のベクトルが与えられました")
        return float('inf')
    
    # ベクトルの長さを揃える
    min_len = min(len(v1), len(v2))
    v1 = v1[:min_len]
    v2 = v2[:min_len]
    
    # 距離関数を取得
    distance_func = get_distance_function(distance_name)
    
    # 要素ごとの距離を計算して合計
    total_distance = sum(distance_func(x, y) for x, y in zip(v1, v2))
    
    # 距離の平均を返す
    return total_distance / min_len

def calculate_multivariate_distance(new_data: Dict[str, Any], 
                                   reference_data: Dict[str, Any], 
                                   feature_columns: List[str],
                                   distance_name: str = 'Manhattan') -> float:
    """
    特徴量ごとの距離の平均を計算します。
    
    Parameters
    ----------
    new_data : Dict[str, Any]
        新しいデータポイント
    reference_data : Dict[str, Any]
        参照データポイント
    feature_columns : List[str]
        距離計算に使用する特徴量リスト
    distance_name : str, default='Manhattan'
        使用する距離関数の名前
        
    Returns
    -------
    float
        平均距離
    """
    total_distance = 0.0
    valid_features = 0
    
    for feature in feature_columns:
        if feature in new_data and feature in reference_data:
            # 特徴量の値を取得
            new_val = new_data[feature]
            ref_val = reference_data[feature]
            
            # 数値データのみ処理
            if isinstance(new_val, (int, float)) and isinstance(ref_val, (int, float)):
                # 距離を計算
                feature_distance = calculate_scalar_distance(new_val, ref_val, distance_name)
                total_distance += feature_distance
                valid_features += 1
            else:
                logger.warning(f"数値以外の特徴量をスキップ: {feature}")
    
    if valid_features == 0:
        logger.warning(f"有効な特徴量がありません。使用可能: new_data={list(new_data.keys())}, reference_data={list(reference_data.keys())}")
        return float('inf')
        
    # 平均距離を返す
    return total_distance / valid_features