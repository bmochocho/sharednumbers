"""
オンライン学習のバックテスト機能を提供するモジュール

オンライン学習環境におけるバックテスト実行と評価を行います。
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from typing import TypeAlias, List, Dict, Any, Optional, Union, Literal
import logging
from pythonjsonlogger import jsonlogger

# ローカルモジュールをインポート
from ..online_pooling_dtw_knn import OnlinePoolingDTWKNN
from ..data_loader import DatabaseConfig, DataSelectionCriteria
from ..distance import DTWParameters
from .backtest_base import BacktestOptions, BacktestResult, calculate_metrics, visualize_results

# ロギング設定
logger = logging.getLogger(__name__)
logHandler = logging.StreamHandler()
formatter = jsonlogger.JsonFormatter('%(asctime)s %(name)s %(levelname)s %(message)s')
logHandler.setFormatter(formatter)
logger.addHandler(logHandler)

# 型エイリアス
PathType: TypeAlias = Path
DataPoint = Dict[str, Any]
DataList = List[DataPoint]
KParam = Union[int, List[Union[int, float]], Literal["*"]]

def run_backtest(model: OnlinePoolingDTWKNN, 
                feature_columns: List[str], 
                options: Optional[BacktestOptions] = None) -> BacktestResult:
    """
    モデルに対してバックテストを実行します。
    
    Parameters
    ----------
    model : OnlinePoolingDTWKNN
        テスト対象のモデル
    feature_columns : List[str]
        DTW計算に使用する特徴量
    options : Optional[BacktestOptions], default=None
        バックテストオプション
        
    Returns
    -------
    BacktestResult
        バックテスト結果
    """
    # デフォルトオプションを使用
    if options is None:
        options = BacktestOptions()
    
    # 検証データを取得
    validation_data = model.valid_update_queue
    logger.info(f"検証データポイント: {len(validation_data)}")
    
    true_labels = []
    pred_labels = []
    timestamps = []
    distances = []
    
    # 各検証データポイントを処理
    for i, data_point in enumerate(validation_data):
        # 真のラベルを抽出
        if 'historical_id' not in data_point:
            logger.warning(f"データポイントに historical_id がありません: {list(data_point.keys())}")
            continue
            
        true_label = data_point['historical_id'].split('_')[0]
        true_labels.append(true_label)
        
        # タイムスタンプを記録
        if 'timestamp' in data_point:
            timestamps.append(data_point['timestamp'])
        
        # モデルを使用して予測
        predicted_label = model.predict(data_point, feature_columns)
        pred_labels.append(predicted_label)
        
        # 最近傍の距離を記録
        if model.explains and 'distance' in model.explains[0]:
            distances.append(model.explains[0]['distance'])
        
        # オンラインモードの場合、新しいデータでモデルを更新
        if options.online_update:
            model.add_data(data_point, true_label)
            model.update()
        
        # 進捗状況を報告
        if (i + 1) % 10 == 0 or i == len(validation_data) - 1:
            logger.info(f"処理済み: {i + 1}/{len(validation_data)} データポイント")
    
    # 評価指標を計算
    result = calculate_metrics(true_labels, pred_labels, timestamps, distances)
    
    # 結果を可視化・保存
    if options.plot_results or options.save_results:
        visualize_results(result, "backtest_results", options)
    
    return result

def run_file_based_backtest(data_dir: PathType,
                          train_hil: List[List[str]],
                          valid_hil: List[str],
                          split_date: str,
                          feature_columns: List[str],
                          k_values: List[KParam] = [3],
                          options: Optional[BacktestOptions] = None) -> Dict[str, BacktestResult]:
    """
    ファイルベースのデータでバックテストを実行します。
    
    Parameters
    ----------
    data_dir : PathType
        データファイルが格納されているディレクトリ
    train_hil : List[List[str]]
        トレーニング用の履歴ID
    valid_hil : List[str]
        検証用の履歴ID
    split_date : str
        トレーニングと検証データを分割するタイムスタンプ
    feature_columns : List[str]
        特徴量として使用するカラム
    k_values : List[KParam], default=[3]
        テストするkパラメータのリスト
    options : Optional[BacktestOptions], default=None
        バックテストオプション
        
    Returns
    -------
    Dict[str, BacktestResult]
        各kパラメータのバックテスト結果
    """
    if options is None:
        options = BacktestOptions()
    
    # 比較が必要かどうか
    if len(k_values) > 1:
        # 複数のkパラメータで比較
        return compare_k_values(
            data_dir=data_dir,
            train_hil=train_hil,
            valid_hil=valid_hil,
            split_date=split_date,
            feature_columns=feature_columns,
            k_values=k_values,
            options=options,
            mode="file"
        )
    else:
        # 単一のkパラメータでバックテスト
        model = OnlinePoolingDTWKNN(
            k=k_values[0],
            train_hil=train_hil,
            valid_hil=valid_hil,
            between_train_to_valid=split_date,
            dtw_parameters=DTWParameters()
        )
        
        # データを読み込む
        model.load_data(data_dir)
        
        # バックテストを実行
        result = run_backtest(model, feature_columns, options)
        return {str(k_values[0]): result}

def run_db_based_backtest(db_config: DatabaseConfig,
                        criteria: DataSelectionCriteria,
                        k_values: List[KParam] = [3],
                        options: Optional[BacktestOptions] = None) -> Dict[str, BacktestResult]:
    """
    データベースのデータでバックテストを実行します。
    
    Parameters
    ----------
    db_config : DatabaseConfig
        データベース接続設定
    criteria : DataSelectionCriteria
        データ選択基準
    k_values : List[KParam], default=[3]
        テストするkパラメータのリスト
    options : Optional[BacktestOptions], default=None
        バックテストオプション
        
    Returns
    -------
    Dict[str, BacktestResult]
        各kパラメータのバックテスト結果
    """
    if options is None:
        options = BacktestOptions()
    
    # 比較が必要かどうか
    if len(k_values) > 1:
        # 複数のkパラメータで比較
        return compare_k_values(
            db_config=db_config,
            criteria=criteria,
            k_values=k_values,
            options=options,
            mode="db"
        )
    else:
        # 単一のkパラメータでバックテスト
        model = OnlinePoolingDTWKNN(
            k=k_values[0],
            dtw_parameters=DTWParameters()
        )
        
        # データを読み込む
        model.load_data_from_db(db_config, criteria)
        
        # バックテストを実行
        result = run_backtest(model, criteria.feature_columns, options)
        return {str(k_values[0]): result}

def compare_k_values(k_values: List[KParam],
                    options: BacktestOptions,
                    mode: str = "file",
                    **kwargs) -> Dict[str, BacktestResult]:
    """
    異なるkパラメータでのモデルパフォーマンスを比較します。
    
    Parameters
    ----------
    k_values : List[KParam]
        テストするkパラメータのリスト
    options : BacktestOptions
        バックテストオプション
    mode : str, default="file"
        バックテストモード ("file" または "db")
    **kwargs
        モード固有のパラメータ
        
    Returns
    -------
    Dict[str, BacktestResult]
        各kパラメータのバックテスト結果
    """
    results = {}
    comparison_data = []
    
    for k in k_values:
        logger.info(f"k = {k} でバックテスト実行中...")
        
        if mode == "file":
            # ファイルベースモード
            data_dir = kwargs.get("data_dir")
            train_hil = kwargs.get("train_hil")
            valid_hil = kwargs.get("valid_hil")
            split_date = kwargs.get("split_date")
            feature_columns = kwargs.get("feature_columns")
            
            # モデルを初期化
            model = OnlinePoolingDTWKNN(
                k=k,
                train_hil=train_hil,
                valid_hil=valid_hil,
                between_train_to_valid=split_date,
                dtw_parameters=DTWParameters()
            )
            
            # データを読み込む
            model.load_data(data_dir)
            
            # バックテストを実行
            result = run_backtest(model, feature_columns, options)
            
        elif mode == "db":
            # データベースベースモード
            db_config = kwargs.get("db_config")
            criteria = kwargs.get("criteria")
            
            # モデルを初期化
            model = OnlinePoolingDTWKNN(
                k=k,
                dtw_parameters=DTWParameters()
            )
            
            # データを読み込む
            model.load_data_from_db(db_config, criteria)
            
            # バックテストを実行
            result = run_backtest(model, criteria.feature_columns, options)
            
        else:
            # 不明なモード
            logger.error(f"不明なバックテストモード: {mode}")
            return {}
        
        # 結果を保存
        results[str(k)] = result
        
        # 比較データに追加
        comparison_data.append({
            'k': str(k),
            'accuracy': result.accuracy
        })
    
    # 比較結果を可視化
    if options.plot_results or options.save_results:
        plt.figure(figsize=(10, 6))
        plt.title("異なるkパラメータでの正解率比較")
        
        # データを準備
        k_values_str = [str(k) for k in k_values]
        accuracies = [results[str(k)].accuracy for k in k_values]
        
        # 棒グラフでプロット
        plt.bar(k_values_str, accuracies, color='skyblue')
        plt.ylim(0, 1)
        plt.xlabel('kパラメータ')
        plt.ylabel('正解率')
        
        # 各バーに値を表示
        for i, acc in enumerate(accuracies):
            plt.text(i, acc + 0.02, f'{acc:.4f}', ha='center')
        
        plt.grid(True, alpha=0.3, axis='y')
        
        # 画像として保存または表示
        if options.save_results:
            plt.savefig(options.output_dir / "k_comparison.png")
            
            # CSVとしても保存
            pd.DataFrame(comparison_data).to_csv(
                options.output_dir / "k_comparison.csv", index=False
            )
            
            # 比較レポートを保存
            report_path = options.output_dir / "k_comparison_report.txt"
            with open(report_path, 'w') as f:
                f.write(f"kパラメータ比較結果:\n")
                for k, acc in zip(k_values_str, accuracies):
                    f.write(f"k = {k}: 正解率 = {acc:.4f}\n")
                
                # 最適なkを特定
                best_k = k_values_str[np.argmax(accuracies)]
                best_acc = max(accuracies)
                f.write(f"\n最適なk: {best_k} (正解率: {best_acc:.4f})")
        
        if options.plot_results:
            plt.show()
        else:
            plt.close()
    
    return results