"""
予測器の基本クラスと機能を定義するモジュール

様々な予測器の共通インターフェースと基本機能を提供します。
カスタム予測器を実装するための基底クラスとなります。
"""

import logging
from pythonjsonlogger import jsonlogger
from pathlib import Path
from typing import TypeAlias, List, Dict, Any, Optional
from abc import ABC, abstractmethod
import numpy as np

# ロギング設定
logger = logging.getLogger(__name__)
logHandler = logging.StreamHandler()
formatter = jsonlogger.JsonFormatter('%(asctime)s %(name)s %(levelname)s %(message)s')
logHandler.setFormatter(formatter)
logger.addHandler(logHandler)

# 型エイリアス
PathType: TypeAlias = Path
DataPoint = Dict[str, Any]
DataList = List[DataPoint]
FeatureList = List[str]

class PredictorBase(ABC):
    """
    すべての予測器のベースとなる抽象基底クラス
    
    このクラスは予測器の共通インターフェースを定義し、
    共通の機能を実装します。
    
    Attributes
    ----------
    train_data : DataList
        トレーニングデータ
    valid_data : DataList
        検証データ
    explains : List[Dict[str, Any]]
        予測の説明情報
    """
    
    def __init__(self, **kwargs):
        """
        予測器の初期化
        
        Parameters
        ----------
        **kwargs
            追加の初期化パラメータ
        """
        self.train_data: DataList = []
        self.valid_data: DataList = []
        self.explains: List[Dict[str, Any]] = []
        logger.info(f"{self.__class__.__name__} 予測器を初期化しました")
    
    @abstractmethod
    def predict(self, data_point: DataPoint, features: FeatureList) -> str:
        """
        新しいデータポイントに対して予測を行う
        
        Parameters
        ----------
        data_point : DataPoint
            予測対象のデータポイント
        features : FeatureList
            予測に使用する特徴量リスト
            
        Returns
        -------
        str
            予測結果（ラベル）
        """
        pass
    
    @abstractmethod
    def add_data(self, data_point: DataPoint, label: str) -> None:
        """
        新しいデータポイントをトレーニングデータに追加
        
        Parameters
        ----------
        data_point : DataPoint
            追加するデータポイント
        label : str
            データポイントのラベル
        """
        pass
    
    @abstractmethod
    def update(self, data_point: Optional[DataPoint] = None) -> None:
        """
        モデルを更新する
        
        Parameters
        ----------
        data_point : Optional[DataPoint], default=None
            更新に使用するデータポイント（None の場合は内部キューから取得）
        """
        pass
    
    def evaluate(self, test_data: DataList, features: FeatureList, 
                update_model: bool = False) -> Dict[str, Any]:
        """
        テストデータセットに対してモデルを評価
        
        Parameters
        ----------
        test_data : DataList
            評価用テストデータ
        features : FeatureList
            評価に使用する特徴量
        update_model : bool, default=False
            評価中にモデルを更新するかどうか
            
        Returns
        -------
        Dict[str, Any]
            評価結果を含む辞書
        """
        true_labels = []
        pred_labels = []
        distances = []
        
        for i, data_point in enumerate(test_data):
            # 真のラベルを取得
            if 'historical_id' in data_point:
                true_label = data_point['historical_id'].split('_')[0]
                true_labels.append(true_label)
                
                # 予測
                predicted_label = self.predict(data_point, features)
                pred_labels.append(predicted_label)
                
                # 距離情報があれば記録
                if self.explains and 'distance' in self.explains[0]:
                    distances.append(self.explains[0]['distance'])
                
                # オプションでモデルを更新
                if update_model:
                    self.add_data(data_point, true_label)
                    self.update()
                
                # 進捗報告
                if (i + 1) % 10 == 0:
                    logger.info(f"評価進捗: {i + 1}/{len(test_data)}")
        
        # 正確度を計算
        correct = sum(1 for t, p in zip(true_labels, pred_labels) if t == p)
        total = len(true_labels)
        accuracy = correct / total if total > 0 else 0
        
        return {
            "true_labels": true_labels,
            "pred_labels": pred_labels,
            "distances": distances,
            "accuracy": accuracy,
            "correct": correct,
            "total": total
        }
    
    def get_label_from_id(self, historical_id: str) -> str:
        """
        履歴IDからラベルを抽出
        
        Parameters
        ----------
        historical_id : str
            履歴ID
            
        Returns
        -------
        str
            抽出されたラベル
        """
        # 通常、履歴IDは "ラベル_連番" の形式
        parts = historical_id.split('_')
        if len(parts) > 0:
            return parts[0]
        return "unknown"