"""
データローダーモジュール

各種データソースからデータを読み込むための機能を提供します。
"""

from .read_parquet import (
    DatabaseConfig,
    DataSelectionCriteria,
    load_from_parquet,
    load_from_database,
    process_data,
    create_synthetic_database
)