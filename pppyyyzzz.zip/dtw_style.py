"""
DTW (Dynamic Time Warping) 距離計算モジュール

時系列データの比較に適したDTW距離を計算する機能を提供します。
"""

import numpy as np
import logging
from pythonjsonlogger import jsonlogger
from typing import TypeAlias, List, Dict, Any, Union, Optional
from pydantic import BaseModel, Field

from .distance_base import get_distance_function, calculate_scalar_distance

# ロギング設定
logger = logging.getLogger(__name__)
logHandler = logging.StreamHandler()
formatter = jsonlogger.JsonFormatter('%(asctime)s %(name)s %(levelname)s %(message)s')
logHandler.setFormatter(formatter)
logger.addHandler(logHandler)

# 型エイリアス
Vector = List[Union[float, int]]
DataPoint = Dict[str, Any]

class DTWParameters(BaseModel):
    """
    Dynamic Time Warpingのパラメータを保持するモデル
    
    このクラスは、DTW距離計算のための様々なパラメータをカプセル化します。
    距離関数の種類、帯域幅（Sakoe-Chiba band）、および動的計画法で使用される
    係数（挿入、削除、一致）を指定します。
    
    Attributes
    ----------
    distance_name : str
        使用する距離関数の名前（'Manhattan', 'Euclidean', 'Maximum'）
    sakoechiba_distance : int
        Sakoe-Chiba帯域幅（DTW計算の効率化のための制約）
    coefficient_insertion : float
        挿入操作の係数（0_1）
    coefficient_deletion : float
        削除操作の係数（1_0）
    coefficient_match : float
        一致操作の係数（1_1）
    """
    distance_name: str = 'Manhattan'
    sakoechiba_distance: int = 0
    coefficient_insertion: float = 1.0  # 挿入係数 (0_1)
    coefficient_deletion: float = 1.0   # 削除係数 (1_0)
    coefficient_match: float = 1.0      # 一致係数 (1_1)

def dtw_distance(series1: np.ndarray, 
                series2: np.ndarray, 
                params: Optional[DTWParameters] = None) -> float:
    """
    2つの時系列間のDTW距離を計算します。
    
    Parameters
    ----------
    series1 : np.ndarray
        最初の時系列
    series2 : np.ndarray
        2番目の時系列
    params : Optional[DTWParameters], default=None
        DTW計算パラメータ。指定がなければデフォルト値を使用。
        
    Returns
    -------
    float
        DTW距離
    
    Notes
    -----
    DTWアルゴリズムは、2つの時系列間の最適なアライメントを見つけ、
    それに基づいて距離を計算します。Sakoe-Chibaバンドを使用して
    計算範囲を制限し、効率を向上させています。
    """
    if params is None:
        params = DTWParameters()
        
    n, m = len(series1), len(series2)
    
    # 距離関数を取得
    distance_func = get_distance_function(params.distance_name)
    
    # サコエチバ帯域幅（制約）
    w = max(params.sakoechiba_distance, abs(n - m))
    
    # DTW行列を初期化
    dtw_matrix = np.full((n + 1, m + 1), np.inf)
    dtw_matrix[0, 0] = 0
    
    # DTW計算
    for i in range(1, n + 1):
        # 帯域幅制約を適用
        start_j = max(1, i - w)
        end_j = min(m + 1, i + w + 1)
        
        for j in range(start_j, end_j):
            # 現在のポイント間の距離
            cost = distance_func(series1[i - 1], series2[j - 1])
            
            # 最小コスト経路を計算
            dtw_matrix[i, j] = cost + min(
                params.coefficient_insertion * dtw_matrix[i - 1, j],     # 挿入
                params.coefficient_deletion * dtw_matrix[i, j - 1],      # 削除
                params.coefficient_match * dtw_matrix[i - 1, j - 1]      # 一致
            )
    
    return dtw_matrix[n, m]

def multivariate_dtw(new_data: DataPoint, 
                    reference_data: DataPoint, 
                    feature_columns: List[str], 
                    params: Optional[DTWParameters] = None) -> float:
    """
    多変量時系列間のDTW距離を計算します。
    
    Parameters
    ----------
    new_data : DataPoint
        新しいデータポイント（特徴量をキーとする辞書）
    reference_data : DataPoint
        参照データポイント（特徴量をキーとする辞書）
    feature_columns : List[str]
        DTW計算に使用する特徴量のリスト
    params : Optional[DTWParameters], default=None
        DTW計算パラメータ。指定がなければデフォルト値を使用。
        
    Returns
    -------
    float
        多変量DTW距離
        
    Notes
    -----
    各特徴量ごとにDTW距離を計算し、その平均を返します。
    特徴量が欠損している場合や数値でない場合は無視されます。
    有効な特徴量がない場合は無限大を返します。
    """
    if params is None:
        params = DTWParameters()
        
    total_distance = 0.0
    valid_features = 0
    
    for feature in feature_columns:
        if feature in new_data and feature in reference_data:
            # 単一特徴量のDTW距離を計算
            new_val = new_data[feature]
            ref_val = reference_data[feature]
            
            # 数値データのみ処理
            if isinstance(new_val, (int, float)) and isinstance(ref_val, (int, float)):
                # 単一値なので、直接計算関数を使用
                distance = calculate_scalar_distance(new_val, ref_val, params.distance_name)
                total_distance += distance
                valid_features += 1
            else:
                logger.warning(f"数値以外の特徴量をスキップ: {feature}")
    
    if valid_features == 0:
        logger.warning(f"有効な特徴量がありません。使用可能: new_data={list(new_data.keys())}, reference_data={list(reference_data.keys())}")
        return float('inf')
        
    # 平均距離を返す
    return total_distance / valid_features

def dtw_matrix(series1: List[float], 
              series2: List[float], 
              params: Optional[DTWParameters] = None) -> np.ndarray:
    """
    2つの時系列間のDTW距離行列を計算します。
    
    Parameters
    ----------
    series1 : List[float]
        最初の時系列
    series2 : List[float]
        2番目の時系列
    params : Optional[DTWParameters], default=None
        DTW計算パラメータ。指定がなければデフォルト値を使用。
        
    Returns
    -------
    np.ndarray
        DTW距離行列
    """
    if params is None:
        params = DTWParameters()
    
    n, m = len(series1), len(series2)
    
    # 距離関数を取得
    distance_func = get_distance_function(params.distance_name)
    
    # サコエチバ帯域幅（制約）
    w = max(params.sakoechiba_distance, abs(n - m))
    
    # DTW行列を初期化
    dtw_matrix = np.full((n + 1, m + 1), np.inf)
    dtw_matrix[0, 0] = 0
    
    # DTW計算
    for i in range(1, n + 1):
        # 帯域幅制約を適用
        start_j = max(1, i - w)
        end_j = min(m + 1, i + w + 1)
        
        for j in range(start_j, end_j):
            # 現在のポイント間の距離
            cost = distance_func(series1[i - 1], series2[j - 1])
            
            # 最小コスト経路を計算
            dtw_matrix[i, j] = cost + min(
                params.coefficient_insertion * dtw_matrix[i - 1, j],
                params.coefficient_deletion * dtw_matrix[i, j - 1],
                params.coefficient_match * dtw_matrix[i - 1, j - 1]
            )
    
    return dtw_matrix

def dtw_path(dtw_matrix: np.ndarray) -> List[tuple]:
    """
    DTW距離行列から最適パスを抽出します。
    
    Parameters
    ----------
    dtw_matrix : np.ndarray
        DTW距離行列
        
    Returns
    -------
    List[tuple]
        (i, j) ペアのリストとして表される最適パス
    """
    n, m = dtw_matrix.shape
    n -= 1
    m -= 1
    
    path = [(n, m)]
    
    while n > 0 or m > 0:
        if n == 0:
            m -= 1
        elif m == 0:
            n -= 1
        else:
            options = [
                (n-1, m),    # 挿入
                (n, m-1),    # 削除
                (n-1, m-1)   # 一致
            ]
            
            # 最小コストの移動を選択
            costs = [dtw_matrix[i, j] for i, j in options]
            idx = np.argmin(costs)
            n, m = options[idx]
        
        path.append((n, m))
    
    # パスを逆順にして返す
    return path[::-1]