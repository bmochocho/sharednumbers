"""
距離計算モジュール

時系列データ間の距離計算機能を提供します。
基本的な距離関数とDTW（Dynamic Time Warping）距離を実装しています。
"""

from .distance_base import (
    get_distance_function,
    calculate_scalar_distance,
    euclidean_distance,
    manhattan_distance,
    maximum_distance
)

from .dtw_style import (
    DTWParameters,
    dtw_distance,
    multivariate_dtw
)