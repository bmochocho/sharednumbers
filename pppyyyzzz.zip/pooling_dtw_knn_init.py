"""
OnlinePoolingDTWKNN パッケージ

Dynamic Time Warping (DTW) 距離を用いたk-NN手法によるオンライン学習が可能な
時系列データ予測モデルを提供します。
"""

from .online_pooling_dtw_knn import OnlinePoolingDTWKNN