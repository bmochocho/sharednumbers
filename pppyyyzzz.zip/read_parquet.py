"""
Parquetファイルなど各種データソースからのデータ読み込み機能

データファイルやデータベースからのデータ読み込みと前処理を行います。
"""

import pandas as pd
import sqlite3
import numpy as np
from pathlib import Path
from typing import TypeAlias, List, Dict, Any, Optional
from datetime import datetime, timedelta
from pydantic import BaseModel, Field, ConfigDict
import logging
from pythonjsonlogger import jsonlogger

# ロギング設定
logger = logging.getLogger(__name__)
logHandler = logging.StreamHandler()
formatter = jsonlogger.JsonFormatter('%(asctime)s %(name)s %(levelname)s %(message)s')
logHandler.setFormatter(formatter)
logger.addHandler(logHandler)

# 型エイリアス
PathType: TypeAlias = Path
DataPoint = Dict[str, Any]
DataList = List[DataPoint]
DataFrameList = List[pd.DataFrame]

class DatabaseConfig(BaseModel):
    """
    データベース接続設定を保持するモデル
    
    このクラスは、データベースへの接続とクエリに必要な設定情報をカプセル化します。
    SQLiteデータベースへのパスやテーブル名、主要なカラム名を指定します。
    
    Attributes
    ----------
    db_path : Path
        データベースファイルへのパス
    symbol_table : str
        銘柄（シンボル）情報を格納するテーブル名
    price_table : str
        価格データを格納するテーブル名
    symbol_id_column : str
        銘柄を識別するためのカラム名
    timestamp_column : str
        時間情報を格納するカラム名
    """
    db_path: Path
    symbol_table: str = "symbols"  # 銘柄情報を含むテーブル
    price_table: str = "prices"    # 価格データを含むテーブル
    symbol_id_column: str = "symbol_id"  # 銘柄IDカラム
    timestamp_column: str = "timestamp"  # タイムスタンプカラム
    
    model_config = ConfigDict(arbitrary_types_allowed=True)

class DataSelectionCriteria(BaseModel):
    """
    データ選択基準を保持するモデル
    
    このクラスは、データベースからデータを選択する際の条件をカプセル化します。
    日付範囲、トレーニング/テスト分割日、分析対象の銘柄、使用する特徴量などを指定します。
    
    Attributes
    ----------
    start_date : str
        データの開始日 (YYYY-MM-DD形式)
    end_date : str
        データの終了日 (YYYY-MM-DD形式)
    train_test_split_date : str
        トレーニングセットとテストセットを分割する日付
    train_symbols : List[str]
        トレーニングに使用する銘柄コードのリスト
    valid_symbols : List[str]
        検証に使用する銘柄コードのリスト
    feature_columns : List[str]
        分析に使用する特徴量（カラム名）のリスト
    """
    start_date: str  # 開始日 (YYYY-MM-DD形式)
    end_date: str    # 終了日 (YYYY-MM-DD形式)
    train_test_split_date: str  # トレーニングとテストの分割日
    train_symbols: List[str] = Field(default_factory=list)  # トレーニングに使用する銘柄リスト
    valid_symbols: List[str] = Field(default_factory=list)  # 検証に使用する銘柄リスト
    feature_columns: List[str] = Field(default_factory=list)  # 特徴量として使用するカラム

def load_from_parquet(directory: PathType, 
                     train_hil: List[List[str]], 
                     valid_hil: List[str]) -> Dict[str, Any]:
    """
    パーケットファイルからデータを読み込みます。
    
    Parameters
    ----------
    directory : PathType
        データファイルが格納されているディレクトリパス
    train_hil : List[List[str]]
        トレーニング用の履歴ID。二重のリスト構造になっています。
    valid_hil : List[str]
        検証用の履歴ID
        
    Returns
    -------
    Dict[str, Any]
        読み込まれたデータを含む辞書
        - train_dfl: トレーニングデータフレームのリスト
        - valid_dfl: 検証データフレームのリスト
    """
    train_dfl = []
    valid_dfl = []
    
    # トレーニングデータの読み込み
    for hil_list in train_hil:
        for hil in hil_list:
            try:
                file_path = Path(directory) / f"{hil}.parquet"
                df = pd.read_parquet(file_path)
                train_dfl.append(df)
                logger.info(f"トレーニングデータを読み込みました: {hil}")
            except Exception as e:
                logger.error(f"トレーニングデータ {hil} の読み込みエラー: {e}")

    # 検証データの読み込み
    for hil in valid_hil:
        try:
            file_path = Path(directory) / f"{hil}.parquet"
            df = pd.read_parquet(file_path)
            valid_dfl.append(df)
            logger.info(f"検証データを読み込みました: {hil}")
        except Exception as e:
            logger.error(f"検証データ {hil} の読み込みエラー: {e}")
            
    return {
        "train_dfl": train_dfl,
        "valid_dfl": valid_dfl
    }

def load_from_database(db_config: DatabaseConfig, 
                      criteria: DataSelectionCriteria) -> Dict[str, Any]:
    """
    データベースからデータを読み込みます。
    
    Parameters
    ----------
    db_config : DatabaseConfig
        データベース接続設定
    criteria : DataSelectionCriteria
        データ選択基準
        
    Returns
    -------
    Dict[str, Any]
        読み込まれたデータを含む辞書
        - train_dfl: トレーニングデータフレームのリスト
        - valid_dfl: 検証データフレームのリスト
        - train_symbols: トレーニング銘柄のリスト
        - valid_symbols: 検証銘柄のリスト
        - split_date: 分割日
    """
    try:
        # データベースに接続
        conn = sqlite3.connect(db_config.db_path)
        
        # トレーニングデータの読み込み
        train_dfl = []
        for symbol in criteria.train_symbols:
            df = _fetch_symbol_data(
                conn, 
                db_config,
                symbol, 
                criteria.start_date, 
                criteria.end_date, 
                criteria.feature_columns
            )
            if not df.empty:
                train_dfl.append(df)
                logger.info(f"トレーニングデータを読み込みました: {symbol}, {len(df)}行")
            else:
                logger.warning(f"トレーニング銘柄データが空です: {symbol}")
        
        # 検証データの読み込み
        valid_dfl = []
        for symbol in criteria.valid_symbols:
            df = _fetch_symbol_data(
                conn, 
                db_config,
                symbol,
                criteria.start_date, 
                criteria.end_date, 
                criteria.feature_columns
            )
            if not df.empty:
                valid_dfl.append(df)
                logger.info(f"検証データを読み込みました: {symbol}, {len(df)}行")
            else:
                logger.warning(f"検証銘柄データが空です: {symbol}")
        
        # 接続を閉じる
        conn.close()
        
        return {
            "train_dfl": train_dfl,
            "valid_dfl": valid_dfl,
            "train_symbols": criteria.train_symbols,
            "valid_symbols": criteria.valid_symbols,
            "split_date": criteria.train_test_split_date
        }
        
    except Exception as e:
        logger.error(f"データベースからのデータ読み込みエラー: {e}")
        return {
            "train_dfl": [],
            "valid_dfl": [],
            "error": str(e)
        }

def _fetch_symbol_data(conn: sqlite3.Connection, 
                      db_config: DatabaseConfig,
                      symbol: str, 
                      start_date: str, 
                      end_date: str, 
                      feature_columns: List[str]) -> pd.DataFrame:
    """
    データベースから特定の銘柄のデータを取得します。
    
    Parameters
    ----------
    conn : sqlite3.Connection
        SQLite接続オブジェクト
    db_config : DatabaseConfig
        データベース設定
    symbol : str
        取得する銘柄ID
    start_date : str
        開始日 (YYYY-MM-DD形式)
    end_date : str
        終了日 (YYYY-MM-DD形式)
    feature_columns : List[str]
        取得する特徴量カラム
        
    Returns
    -------
    pd.DataFrame
        取得したデータフレーム
    """
    try:
        # 特徴量カラムをクエリに追加
        feature_cols_str = ", ".join(feature_columns)
        
        # クエリを構築
        query = f"""
        SELECT 
            {db_config.timestamp_column} as timestamp,
            '{symbol}' as historical_id,
            {feature_cols_str}
        FROM 
            {db_config.price_table}
        WHERE 
            {db_config.symbol_id_column} = ?
            AND {db_config.timestamp_column} BETWEEN ? AND ?
        ORDER BY 
            {db_config.timestamp_column} ASC
        """
        
        # クエリを実行
        df = pd.read_sql_query(
            query, 
            conn, 
            params=[symbol, start_date, end_date]
        )
        
        return df
    
    except Exception as e:
        logger.error(f"銘柄 {symbol} のデータ取得エラー: {e}")
        return pd.DataFrame()

def process_data(train_dfl: DataFrameList, 
                valid_dfl: DataFrameList, 
                split_date: str) -> Dict[str, Any]:
    """
    読み込まれたデータをトレーニングと検証用に処理します。
    
    Parameters
    ----------
    train_dfl : DataFrameList
        トレーニングデータフレームのリスト
    valid_dfl : DataFrameList
        検証データフレームのリスト
    split_date : str
        トレーニングと検証データを分割するタイムスタンプ
        
    Returns
    -------
    Dict[str, Any]
        処理されたデータを含む辞書
        - train_data: 基本トレーニングデータのリスト（辞書形式）
        - train_update_queue: トレーニング更新キュー（辞書形式）
        - valid_update_queue: 検証更新キュー（辞書形式）
    """
    train_data = []
    train_updates = []
    valid_updates = []
    
    # タイムスタンプのチェック
    if not split_date:
        logger.warning("分割タイムスタンプが指定されていません。すべてのデータがトレーニングに使用されます。")
        # すべてのデータをトレーニングに使用
        for df in train_dfl:
            for _, row in df.iterrows():
                train_data.append(row.to_dict())
        for df in valid_dfl:
            for _, row in df.iterrows():
                valid_updates.append(row.to_dict())
    else:
        # トレーニングデータの分割
        for df in train_dfl:
            if 'timestamp' in df.columns:
                # 基本データと更新データに分割
                base_data = df[df['timestamp'] < split_date]
                update_data = df[df['timestamp'] >= split_date]
                
                # ベースデータを追加
                for _, row in base_data.iterrows():
                    train_data.append(row.to_dict())
                
                # 更新データを追加
                for _, row in update_data.iterrows():
                    train_updates.append(row.to_dict())
            else:
                logger.warning(f"DataFrameに 'timestamp' カラムがありません: {df.columns}")
                # すべてのデータをトレーニングに使用
                for _, row in df.iterrows():
                    train_data.append(row.to_dict())

        # 検証データの分割
        for df in valid_dfl:
            if 'timestamp' in df.columns:
                # 更新データのみ取得（検証用）
                update_data = df[df['timestamp'] >= split_date]
                
                # 更新データを追加
                for _, row in update_data.iterrows():
                    valid_updates.append(row.to_dict())
            else:
                logger.warning(f"DataFrameに 'timestamp' カラムがありません: {df.columns}")
    
    # データを返す
    return {
        "train_data": train_data,
        "train_update_queue": train_updates,
        "valid_update_queue": valid_updates
    }

def create_synthetic_database(db_path: Path, 
                            num_symbols: int = 10, 
                            days: int = 365, 
                            feature_columns: Optional[List[str]] = None) -> None:
    """
    テスト用の合成市場データベースを作成します。
    
    Parameters
    ----------
    db_path : Path
        作成するデータベースのパス
    num_symbols : int, default=10
        生成する銘柄数
    days : int, default=365
        生成する日数
    feature_columns : Optional[List[str]], default=None
        生成する特徴量カラム
    """
    logger.info(f"テスト用データベース {db_path} を作成中...")
    
    # データベースに接続（ファイルがなければ作成）
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # シンボル（銘柄）テーブルを作成
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS symbols (
        symbol_id TEXT PRIMARY KEY,
        name TEXT,
        sector TEXT,
        industry TEXT
    )
    ''')
    
    # 価格データテーブルを作成
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS prices (
        id INTEGER PRIMARY KEY,
        symbol_id TEXT,
        timestamp TEXT,
        open REAL,
        high REAL,
        low REAL,
        close REAL,
        volume INTEGER,
        ma5 REAL,
        ma20 REAL,
        rsi14 REAL,
        FOREIGN KEY (symbol_id) REFERENCES symbols (symbol_id)
    )
    ''')
    
    # サンプル銘柄データを作成
    symbols = [
        ('AAPL', 'Apple Inc.', 'Technology', 'Consumer Electronics'),
        ('MSFT', 'Microsoft Corporation', 'Technology', 'Software'),
        ('GOOGL', 'Alphabet Inc.', 'Technology', 'Internet Content & Information'),
        ('AMZN', 'Amazon.com Inc.', 'Consumer Cyclical', 'Internet Retail'),
        ('META', 'Meta Platforms Inc.', 'Technology', 'Internet Content & Information'),
        ('TSLA', 'Tesla Inc.', 'Consumer Cyclical', 'Auto Manufacturers'),
        ('NVDA', 'NVIDIA Corporation', 'Technology', 'Semiconductors'),
        ('JPM', 'JPMorgan Chase & Co.', 'Financial Services', 'Banks'),
        ('V', 'Visa Inc.', 'Financial Services', 'Credit Services'),
        ('JNJ', 'Johnson & Johnson', 'Healthcare', 'Drug Manufacturers')
    ]
    
    # 使用する銘柄数を制限
    symbols = symbols[:num_symbols]
    
    cursor.executemany('INSERT OR REPLACE INTO symbols VALUES (?, ?, ?, ?)', symbols)
    
    # サンプル価格データを生成して挿入
    start_date = datetime(2023, 1, 1)
    end_date = start_date + timedelta(days=days-1)
    
    # 銘柄ごとの特性を定義
    symbol_characteristics = {
        'AAPL': {'base_price': 150, 'volatility': 2.0, 'trend': 20, 'cycle': 40},
        'MSFT': {'base_price': 250, 'volatility': 1.8, 'trend': 25, 'cycle': 45},
        'GOOGL': {'base_price': 120, 'volatility': 2.2, 'trend': 15, 'cycle': 50},
        'AMZN': {'base_price': 100, 'volatility': 3.0, 'trend': 10, 'cycle': 35},
        'META': {'base_price': 200, 'volatility': 2.5, 'trend': -5, 'cycle': 30},
        'TSLA': {'base_price': 300, 'volatility': 4.0, 'trend': -15, 'cycle': 25},
        'NVDA': {'base_price': 180, 'volatility': 3.5, 'trend': 30, 'cycle': 45},
        'JPM': {'base_price': 140, 'volatility': 1.2, 'trend': 5, 'cycle': 60},
        'V': {'base_price': 220, 'volatility': 1.0, 'trend': 10, 'cycle': 55},
        'JNJ': {'base_price': 170, 'volatility': 0.8, 'trend': 2, 'cycle': 70}
    }
    
    # サンプルデータを作成する関数
    def generate_price_series(symbol_id, base_price, volatility, trend, cycle, start_date, end_date):
        """銘柄ごとの特性を持つ価格系列を生成"""
        current_date = start_date
        data = []
        days = (end_date - start_date).days + 1
        
        price = base_price
        for day in range(days):
            current_date = start_date + timedelta(days=day)
            # 土日はスキップ（市場休業日）
            if current_date.weekday() >= 5:  # 5=土曜日, 6=日曜日
                continue
                
            # 日付を文字列形式に変換
            date_str = current_date.strftime('%Y-%m-%d')
            
            # 価格変動の計算（トレンド + サイクル + ランダム）
            trend_component = trend * day / days
            cycle_component = np.sin(day / cycle) * volatility / 2
            random_component = np.random.normal(0, volatility)
            
            # 株価の更新（1%以上の変動があるように調整）
            daily_change = trend_component + cycle_component + random_component
            price = max(0.1, price * (1 + daily_change / 100))
            
            # 日中の値動きを生成
            daily_volatility = volatility * 0.5
            open_price = price * (1 + np.random.normal(0, daily_volatility / 100))
            high_price = max(open_price, price) * (1 + abs(np.random.normal(0, daily_volatility / 100)))
            low_price = min(open_price, price) * (1 - abs(np.random.normal(0, daily_volatility / 100)))
            close_price = price
            
            # 出来高を生成（株価に基づく）
            volume = int(np.random.normal(1000000, 500000) * (1 + abs(daily_change) / 10))
            
            # テクニカル指標を計算（単純化）
            if len(data) >= 20:
                prev_closes = [d[6] for d in data[-20:]]
                ma5 = sum(prev_closes[-5:]) / 5
                ma20 = sum(prev_closes) / 20
                
                # RSIの計算（単純化）
                gains = sum(max(0, prev_closes[i] - prev_closes[i-1]) for i in range(1, 14))
                losses = sum(max(0, prev_closes[i-1] - prev_closes[i]) for i in range(1, 14))
                
                if losses == 0:
                    rsi = 100
                else:
                    rs = gains / losses
                    rsi = 100 - (100 / (1 + rs))
            else:
                ma5 = close_price
                ma20 = close_price
                rsi = 50
            
            data.append((symbol_id, date_str, open_price, high_price, low_price, close_price, volume, ma5, ma20, rsi))
        
        return data
    
    # すべての銘柄のデータを生成して挿入
    all_price_data = []
    for symbol, char in symbol_characteristics.items():
        if symbol in [s[0] for s in symbols]:  # 選択された銘柄のみ処理
            price_data = generate_price_series(
                symbol, 
                char['base_price'], 
                char['volatility'], 
                char['trend'], 
                char['cycle'], 
                start_date, 
                end_date
            )
            all_price_data.extend(price_data)
            logger.info(f"生成: {symbol} - {len(price_data)}日分のデータ")
    
    # ブロックごとにデータを挿入（パフォーマンス向上）
    cursor.executemany('''
    INSERT INTO prices 
    (symbol_id, timestamp, open, high, low, close, volume, ma5, ma20, rsi14) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', all_price_data)
    
    # 変更をコミットして接続を閉じる
    conn.commit()
    conn.close()
    
    logger.info(f"デモデータベースの作成が完了しました: {db_path}")