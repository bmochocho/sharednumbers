"""
バックテストの基本設定と共通機能を提供するモジュール

バックテストオプション、結果評価、可視化機能を実装します。
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from typing import TypeAlias, List, Dict, Any, Optional
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import logging
from pythonjsonlogger import jsonlogger
import os
from datetime import datetime

# ロギング設定
logger = logging.getLogger(__name__)
logHandler = logging.StreamHandler()
formatter = jsonlogger.JsonFormatter('%(asctime)s %(name)s %(levelname)s %(message)s')
logHandler.setFormatter(formatter)
logger.addHandler(logHandler)

# 型エイリアス
PathType: TypeAlias = Path
DataPoint = Dict[str, Any]
DataList = List[DataPoint]

class BacktestOptions:
    """
    バックテストの設定オプションを保持するクラス
    
    Attributes
    ----------
    online_update : bool
        オンラインモードでテストするかどうか
    save_results : bool
        結果をファイルに保存するかどうか
    plot_results : bool
        結果をプロットするかどうか
    output_dir : Optional[Path]
        結果を保存する出力ディレクトリ
    """
    def __init__(self, 
                online_update: bool = True,
                save_results: bool = True,
                plot_results: bool = True,
                output_dir: Optional[Path] = None):
        """
        バックテストオプションの初期化
        
        Parameters
        ----------
        online_update : bool, default=True
            オンラインモードでテストするかどうか
        save_results : bool, default=True
            結果をファイルに保存するかどうか
        plot_results : bool, default=True
            結果をプロットするかどうか
        output_dir : Optional[Path], default=None
            結果を保存する出力ディレクトリ。指定がなければ現在時刻で生成。
        """
        self.online_update = online_update
        self.save_results = save_results
        self.plot_results = plot_results
        
        # 出力ディレクトリを設定
        if output_dir is None and save_results:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_dir = Path(f"./backtest_results_{timestamp}")
            os.makedirs(output_dir, exist_ok=True)
            
        self.output_dir = output_dir

class BacktestResult:
    """
    バックテスト結果を保持するクラス
    
    Attributes
    ----------
    accuracy : float
        正解率
    confusion_matrix : np.ndarray
        混同行列
    classes : List[str]
        クラスリスト
    classification_report : Dict[str, Any]
        分類レポート
    true_labels : List[str]
        真のラベルのリスト
    pred_labels : List[str]
        予測されたラベルのリスト
    timestamps : List[str]
        予測のタイムスタンプのリスト
    distances : List[float]
        予測の距離のリスト
    """
    def __init__(self, 
                accuracy: float = 0.0,
                confusion_matrix: Optional[np.ndarray] = None,
                classes: Optional[List[str]] = None,
                classification_report: Optional[Dict[str, Any]] = None,
                true_labels: Optional[List[str]] = None,
                pred_labels: Optional[List[str]] = None,
                timestamps: Optional[List[str]] = None,
                distances: Optional[List[float]] = None):
        """
        バックテスト結果の初期化
        
        Parameters
        ----------
        accuracy : float, default=0.0
            正解率
        confusion_matrix : Optional[np.ndarray], default=None
            混同行列
        classes : Optional[List[str]], default=None
            クラスリスト
        classification_report : Optional[Dict[str, Any]], default=None
            分類レポート
        true_labels : Optional[List[str]], default=None
            真のラベルのリスト
        pred_labels : Optional[List[str]], default=None
            予測されたラベルのリスト
        timestamps : Optional[List[str]], default=None
            予測のタイムスタンプのリスト
        distances : Optional[List[float]], default=None
            予測の距離のリスト
        """
        self.accuracy = accuracy
        self.confusion_matrix = confusion_matrix or np.array([])
        self.classes = classes or []
        self.classification_report = classification_report or {}
        self.true_labels = true_labels or []
        self.pred_labels = pred_labels or []
        self.timestamps = timestamps or []
        self.distances = distances or []
    
    def to_dict(self) -> Dict[str, Any]:
        """
        結果を辞書形式に変換
        
        Returns
        -------
        Dict[str, Any]
            結果を含む辞書
        """
        return {
            "accuracy": self.accuracy,
            "confusion_matrix": self.confusion_matrix,
            "classes": self.classes,
            "classification_report": self.classification_report,
            "true_labels": self.true_labels,
            "pred_labels": self.pred_labels,
            "timestamps": self.timestamps,
            "distances": self.distances
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'BacktestResult':
        """
        辞書から結果オブジェクトを作成
        
        Parameters
        ----------
        data : Dict[str, Any]
            結果データを含む辞書
            
        Returns
        -------
        BacktestResult
            作成された結果オブジェクト
        """
        return cls(
            accuracy=data.get("accuracy", 0.0),
            confusion_matrix=data.get("confusion_matrix"),
            classes=data.get("classes"),
            classification_report=data.get("classification_report"),
            true_labels=data.get("true_labels"),
            pred_labels=data.get("pred_labels"),
            timestamps=data.get("timestamps"),
            distances=data.get("distances")
        )

def calculate_metrics(true_labels: List[str], 
                    pred_labels: List[str], 
                    timestamps: List[str] = None,
                    distances: List[float] = None) -> BacktestResult:
    """
    予測結果から評価指標を計算します。
    
    Parameters
    ----------
    true_labels : List[str]
        真のラベル
    pred_labels : List[str]
        予測されたラベル
    timestamps : List[str], default=None
        予測のタイムスタンプ
    distances : List[float], default=None
        予測の距離
        
    Returns
    -------
    BacktestResult
        計算された評価指標
    """
    if len(true_labels) != len(pred_labels):
        logger.error(f"ラベルの長さが一致しません: true={len(true_labels)}, pred={len(pred_labels)}")
        return BacktestResult()
    
    # 正解率を計算
    accuracy = accuracy_score(true_labels, pred_labels)
    logger.info(f"正解率: {accuracy:.4f}")
    
    # 混同行列を計算
    classes = sorted(list(set(true_labels)))
    cm = confusion_matrix(true_labels, pred_labels, labels=classes)
    
    # 分類レポートを生成
    report = classification_report(true_labels, pred_labels, output_dict=True)
    
    # 結果を返す
    return BacktestResult(
        accuracy=accuracy,
        confusion_matrix=cm,
        classes=classes,
        classification_report=report,
        true_labels=true_labels,
        pred_labels=pred_labels,
        timestamps=timestamps or [],
        distances=distances or []
    )

def visualize_results(result: BacktestResult, 
                     name_prefix: str, 
                     options: BacktestOptions) -> None:
    """
    バックテスト結果を可視化・保存します。
    
    Parameters
    ----------
    result : BacktestResult
        可視化する結果
    name_prefix : str
        ファイル名の接頭辞
    options : BacktestOptions
        バックテストオプション
    """
    # 結果をCSVに保存
    if options.save_results:
        result_df = pd.DataFrame({
            "true_label": result.true_labels,
            "pred_label": result.pred_labels,
            "correct": [t == p for t, p in zip(result.true_labels, result.pred_labels)],
        })
        
        # タイムスタンプがあれば追加
        if result.timestamps:
            result_df["timestamp"] = result.timestamps
        
        # 距離があれば追加
        if result.distances:
            result_df["distance"] = result.distances
        
        # CSVに保存
        result_df.to_csv(options.output_dir / f"{name_prefix}_predictions.csv", index=False)
    
    # 混同行列を可視化
    plt.figure(figsize=(10, 8))
    plt.title(f"混同行列 - 正解率: {result.accuracy:.4f}")
    
    cm = result.confusion_matrix
    classes = result.classes
    
    # ヒートマップで混同行列を表示
    plt.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
    plt.colorbar()
    
    # 軸ラベルを設定
    tick_marks = range(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)
    
    # 各セルに値を表示
    thresh = cm.max() / 2.0
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            plt.text(j, i, cm[i, j],
                    ha="center", va="center",
                    color="white" if cm[i, j] > thresh else "black")
    
    plt.tight_layout()
    plt.ylabel('真のラベル')
    plt.xlabel('予測されたラベル')
    
    # 画像として保存または表示
    if options.save_results:
        plt.savefig(options.output_dir / f"{name_prefix}_confusion_matrix.png")
    
    if options.plot_results:
        plt.show()
    else:
        plt.close()
    
    # 時系列での正解・不正解を可視化
    if result.timestamps:
        plt.figure(figsize=(15, 6))
        plt.title("時系列での予測結果")
        
        # タイムスタンプをパース
        dates = pd.to_datetime(result.timestamps)
        
        # 正解と不正解のインデックスを取得
        correct_idx = [i for i, (t, p) in enumerate(zip(result.true_labels, result.pred_labels)) 
                    if t == p]
        incorrect_idx = [i for i, (t, p) in enumerate(zip(result.true_labels, result.pred_labels)) 
                       if t != p]
        
        # 正解と不正解をプロット
        plt.scatter([dates[i] for i in correct_idx], [1] * len(correct_idx), 
                   marker='o', c='green', label='正解', alpha=0.7)
        plt.scatter([dates[i] for i in incorrect_idx], [0] * len(incorrect_idx), 
                   marker='x', c='red', label='不正解', alpha=0.7)
        
        plt.yticks([0, 1], ['不正解', '正解'])
        plt.xlabel('日付')
        plt.ylabel('予測結果')
        plt.grid(True, alpha=0.3)
        plt.legend()
        
        # 画像として保存または表示
        if options.save_results:
            plt.savefig(options.output_dir / f"{name_prefix}_time_series.png")
        
        if options.plot_results:
            plt.show()
        else:
            plt.close()

    # 詳細なレポートを保存
    if options.save_results:
        report_path = options.output_dir / f"{name_prefix}_report.txt"
        with open(report_path, 'w') as f:
            f.write(f"バックテスト結果: {name_prefix}\n")
            f.write(f"正解率: {result.accuracy:.4f}\n\n")
            
            f.write("分類レポート:\n")
            f.write(classification_report(result.true_labels, result.pred_labels))
            
            f.write("\n混同行列:\n")
            f.write(str(cm))
            
            f.write("\n\nクラスごとの精度:\n")
            for cls in classes:
                class_indices = [i for i, label in enumerate(result.true_labels) if label == cls]
                class_correct = sum(1 for i in class_indices 
                                 if result.pred_labels[i] == result.true_labels[i])
                class_total = len(class_indices)
                class_acc = class_correct / class_total if class_total > 0 else 0
                f.write(f"{cls}: {class_acc:.4f} ({class_correct}/{class_total})\n")