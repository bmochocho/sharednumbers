"""
OnlinePoolingDTWKNN 実装モジュール

Dynamic Time Warping距離を用いたk-最近傍法による時系列データの分類と予測を行います。
データの追加と更新によるオンライン学習をサポートします。
"""

import logging
from pythonjsonlogger import jsonlogger
from pathlib import Path
from typing import TypeAlias, List, Dict, Any, Optional, Union, Literal
from pydantic import BaseModel, Field, field_validator, ConfigDict

# ローカルモジュールをインポート
from ..predict_base import PredictorBase
from ..distance import DTWParameters, multivariate_dtw
from ..data_loader import (
    DatabaseConfig, 
    DataSelectionCriteria, 
    load_from_parquet, 
    load_from_database, 
    process_data
)

# ロギング設定
logger = logging.getLogger(__name__)
logHandler = logging.StreamHandler()
formatter = jsonlogger.JsonFormatter('%(asctime)s %(name)s %(levelname)s %(message)s')
logHandler.setFormatter(formatter)
logger.addHandler(logHandler)

# 型エイリアス
PathType: TypeAlias = Path
DataPoint = Dict[str, Any]
DataList = List[DataPoint]
FeatureList = List[str]

class OnlinePoolingDTWKNN(PredictorBase):
    """
    時系列データのためのDynamic Time Warpingを用いたk-Nearest Neighbors実装。
    
    このクラスは、時系列データに対してDTW（Dynamic Time Warping）距離を用いた
    k-最近傍法（k-NN）分類を行います。トレーニングデータを継続的に更新する
    オンライン学習をサポートし、様々なデータソースからのデータ読み込みが可能です。
    
    Attributes
    ----------
    k : int | list[int | float] | Literal["*"]
        近傍数または重み。整数の場合は標準的なk-NN、リストの場合は重み付きk-NN、
        "*"の場合はk^{*}-nn法（カスタム重み）を使用。
    dtw_parameters : DTWParameters
        DTW計算パラメータ
    train_hil : list[list[str]]
        トレーニング用の履歴ID
    valid_hil : list[str]
        検証用の履歴ID
    between_train_to_valid : str
        トレーニングと検証データを分割するタイムスタンプ
    train_data : list[dict]
        学習に使用するベースデータ
    train_update_queue : list[dict]
        学習データの更新キュー
    valid_update_queue : list[dict]
        検証データの更新キュー
    explains : list[dict]
        予測の説明情報
    """
    def __init__(self, 
                k: Union[int, List[Union[int, float]], Literal["*"]] = 3,
                dtw_parameters: Optional[DTWParameters] = None,
                train_hil: Optional[List[List[str]]] = None,
                valid_hil: Optional[List[str]] = None,
                between_train_to_valid: str = "",
                **kwargs):
        """
        OnlinePoolingDTWKNNの初期化
        
        Parameters
        ----------
        k : Union[int, List[Union[int, float]], Literal["*"]], default=3
            近傍数または重み
        dtw_parameters : Optional[DTWParameters], default=None
            DTW計算パラメータ。指定がなければデフォルト値を使用。
        train_hil : Optional[List[List[str]]], default=None
            トレーニング用の履歴ID
        valid_hil : Optional[List[str]], default=None
            検証用の履歴ID
        between_train_to_valid : str, default=""
            トレーニングと検証データを分割するタイムスタンプ
        **kwargs
            追加のパラメータ。RDPキーが含まれている場合はデータを読み込みます。
        """
        super().__init__(**kwargs)
        
        # kパラメータの検証と変換
        self.k = self._validate_k(k)
        
        # 属性を初期化
        self.dtw_parameters = dtw_parameters or DTWParameters()
        self.train_hil = train_hil or []
        self.valid_hil = valid_hil or []
        self.between_train_to_valid = between_train_to_valid
        self.train_update_queue = []
        self.valid_update_queue = []
        
        # RDPが提供されている場合、ファイルからデータを読み込む
        if 'RDP' in kwargs:
            self.load_data(kwargs['RDP'])
        
        # data_criteriaとdb_configが提供されている場合、DBからデータを読み込む
        if 'data_criteria' in kwargs and 'db_config' in kwargs:
            self.load_data_from_db(kwargs['db_config'], kwargs['data_criteria'])
            
        logger.info(f"OnlinePoolingDTWKNN初期化完了: k={self.k}, train_hil={len(self.train_hil)}, valid_hil={len(self.valid_hil)}")
    
    def _validate_k(self, k: Union[int, List[Union[int, float]], Literal["*"]]) -> Union[int, List[float]]:
        """
        kパラメータの検証と標準化
        
        Parameters
        ----------
        k : Union[int, List[Union[int, float]], Literal["*"]]
            検証するkパラメータ
            
        Returns
        -------
        Union[int, List[float]]
            検証済みのkパラメータ
            
        Raises
        ------
        ValueError
            kが正の整数でない場合、またはリスト内の要素が数値でない場合
        """
        if isinstance(k, int) and k <= 0:
            raise ValueError("k must be a positive integer.")
        if isinstance(k, list) and not all(isinstance(i, (int, float)) for i in k):
            raise ValueError("All elements in k list must be int or float.")
        if k == "*":
            # k^{*}-nn法のデフォルト重み
            k = [0.5, 0.3, 0.2]
        return k
    
    def load_data(self, data_dir: PathType) -> None:
        """
        指定されたディレクトリからデータを読み込みます。
        
        Parameters
        ----------
        data_dir : PathType
            データファイルが格納されているディレクトリパス
        """
        # データローダーを使用してデータを読み込む
        result = load_from_parquet(data_dir, self.train_hil, self.valid_hil)
        
        # データを処理
        processed_data = process_data(
            result["train_dfl"], 
            result["valid_dfl"], 
            self.between_train_to_valid
        )
        
        # 処理済みデータを設定
        self.train_data = processed_data["train_data"]
        self.train_update_queue = processed_data["train_update_queue"]
        self.valid_update_queue = processed_data["valid_update_queue"]
        
        logger.info(f"データ読み込み完了: トレーニング={len(self.train_data)}件, 更新キュー={len(self.train_update_queue)}件, 検証={len(self.valid_update_queue)}件")
    
    def load_data_from_db(self, db_config: DatabaseConfig, criteria: DataSelectionCriteria) -> None:
        """
        データベースからデータを読み込み、モデルを初期化します。
        
        Parameters
        ----------
        db_config : DatabaseConfig
            データベース接続設定
        criteria : DataSelectionCriteria
            データ選択基準
        """
        # 設定を更新
        self.between_train_to_valid = criteria.train_test_split_date
        
        # 銘柄リストを初期化
        self.train_hil = [[symbol] for symbol in criteria.train_symbols]
        self.valid_hil = criteria.valid_symbols
        
        # データローダーを使用してDBからデータを読み込む
        result = load_from_database(db_config, criteria)
        
        # エラーチェック
        if "error" in result:
            logger.error(f"データのロードに失敗しました: {result['error']}")
            return
        
        # データを処理
        processed_data = process_data(
            result["train_dfl"], 
            result["valid_dfl"], 
            criteria.train_test_split_date
        )
        
        # 処理済みデータを設定
        self.train_data = processed_data["train_data"]
        self.train_update_queue = processed_data["train_update_queue"]
        self.valid_update_queue = processed_data["valid_update_queue"]
        
        logger.info(f"DB読み込み完了: トレーニング={len(self.train_data)}件, 更新キュー={len(self.train_update_queue)}件, 検証={len(self.valid_update_queue)}件")

    def predict(self, data_point: DataPoint, features: FeatureList) -> str:
        """
        DTW距離を用いたk-NNで新しいデータポイントのラベルを予測します。
        
        Parameters
        ----------
        data_point : DataPoint
            ラベル予測の対象となる新しいデータポイント
        features : FeatureList
            DTW計算に使用する特徴量のリスト
            
        Returns
        -------
        str
            予測されたラベル
            
        Raises
        ------
        ValueError
            予測に利用可能なデータがない場合
        """
        if not self.train_data:
            raise ValueError("予測に利用可能なデータがありません")

        # すべてのトレーニングデータとの距離を計算
        distances = []
        for i, train_point in enumerate(self.train_data):
            if i % 10 == 0:
                logger.debug(f"距離計算進捗: {i}/{len(self.train_data)}")
                
            try:
                # 多変量DTW距離を計算
                dist = multivariate_dtw(
                    new_data=data_point, 
                    reference_data=train_point, 
                    feature_columns=features, 
                    params=self.dtw_parameters
                )
                
                # ラベル情報を取得
                if 'historical_id' in train_point:
                    label = self.get_label_from_id(train_point['historical_id'])
                else:
                    # ラベル情報がない場合はインデックスから推測
                    for i, hil_list in enumerate(self.train_hil):
                        if i == len(distances):
                            label = hil_list[0]
                            break
                    else:
                        label = "unknown"
                
                distances.append((dist, label))
            except Exception as e:
                logger.error(f"距離計算エラー: {e}")
        
        # 距離でソート
        distances.sort(key=lambda x: x[0])
        
        # k-NN用の重みと最近傍を取得
        weights = self._get_weights()
        k_actual = min(len(weights), len(distances))
        nearest = distances[:k_actual]
        
        # 最近傍の説明情報を保存
        self.explains = [
            {
                'distance': dist,
                'rank': i + 1,
                'label': label
            }
            for i, (dist, label) in enumerate(nearest)
        ]
        
        # 重み付き投票
        label_votes = {}
        for (dist, label), weight in zip(nearest, weights[:k_actual]):
            if label in label_votes:
                label_votes[label] += weight
            else:
                label_votes[label] = weight
        
        # 最も票を集めたラベルを返す
        if not label_votes:
            logger.warning("有効な投票がありません")
            return "unknown"
            
        predicted_label = max(label_votes.items(), key=lambda x: x[1])[0]
        return predicted_label
    
    def _get_weights(self) -> List[float]:
        """
        k値に基づいて重みリストを取得します。
        
        Returns
        -------
        List[float]
            k-NNまたはkNN*用の重みリスト
        """
        if isinstance(self.k, int):
            # 標準的なk-NN: すべての近傍に均等な重み
            return [1.0 / self.k] * self.k
        else:
            # k^{*}-NN または カスタム重み
            return self.k
    
    def add_data(self, data_point: DataPoint, label: str) -> None:
        """
        新しいデータポイントとラベルを追加します。
        
        Parameters
        ----------
        data_point : DataPoint
            追加する新しいデータポイント
        label : str
            新しいデータポイントのラベル
        """
        # 既存のデータにデータポイントを追加
        self.train_data.append(data_point)
        
        # 関連するラベル情報を追加
        for hil_list in self.train_hil:
            if hil_list[0] == label:
                # 既存のラベルなので追加する必要なし
                return
                
        # 新しいラベルなので追加
        self.train_hil.append([label])
        logger.info(f"新しいラベルを追加しました: {label}")
    
    def update(self, data_point: Optional[DataPoint] = None) -> None:
        """
        モデルを更新します。
        
        Parameters
        ----------
        data_point : Optional[DataPoint], default=None
            更新に使用するデータポイント。Noneの場合は更新キューから取得。
        """
        if data_point is not None:
            # 指定されたデータポイントを使用
            self.train_data.append(data_point)
            logger.info("指定されたデータポイントでモデルを更新しました")
        elif self.train_update_queue:
            # 更新キューから次のデータポイントを取得
            next_update = self.train_update_queue.pop(0)
            self.train_data.append(next_update)
            logger.info("更新キューからデータポイントを追加しました")
        else:
            logger.warning("更新するデータポイントがありません")
    
    def get_nearest_neighbors(self, data_point: DataPoint, features: FeatureList, k: int = None) -> List[Dict[str, Any]]:
        """
        データポイントに最も近い近傍を取得します。
        
        Parameters
        ----------
        data_point : DataPoint
            近傍を探すデータポイント
        features : FeatureList
            距離計算に使用する特徴量
        k : int, optional
            取得する近傍の数。指定がなければ、モデルのkパラメータを使用。
            
        Returns
        -------
        List[Dict[str, Any]]
            近傍情報のリスト。各近傍は距離、ランク、ラベルを含む辞書として返される。
        """
        # 予測を実行（explains が更新される）
        self.predict(data_point, features)
        
        # 指定されたk（または最大値）まで近傍を返す
        if k is None:
            if isinstance(self.k, int):
                k = self.k
            else:
                k = len(self.k)
        
        return self.explains[:k]